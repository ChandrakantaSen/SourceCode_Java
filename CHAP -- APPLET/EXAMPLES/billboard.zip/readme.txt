//##############################################################################
//# APPLET: DynamicBillBoard                             
//# VERSION: 1.21
//# DATE: 3/29/96
//# AUTHOR: Robert Temple (templer@db.erau.edu)
//#
//#   Applet which displays an image on an HTML page.  The image changes to a
//#   new image after a delay.  This change from one image to the next has
//#   some kind of special effect associated with it.  
//#
//##############################################################################
//# USAGE INSTRUCTIONS:
//#   The images this applet uses all must be the same size.  The size of the
//#   applet must be the same size of these images.
//#   
//#   HTML tag:
//#   <applet code="DynamicBillBoard" width="XXX" height="XXX">
//#   <param name="delay" value="5000">
//#   <param name="billboards" value="X">
//#   <param name="bill0" value="XXX.gif,http://X.X.X/XXX.html,quip">
//#   <param name="bill1" value="XXX.gif,http://X.X.X/XXX.html,quip">
//#   <param name="bill2" value="XXX.gif,http://X.X.X/XXX.html,quip">
//#   <param name="bill3" value="XXX.gif,http://X.X.X/XXX.html,quip">
//#   <param name="transitions" value="6,ColumnTransition,XXX...">
//#   <param name="bgcolor" value="#FFFFFF">
//#   </applet>
//#
//#   HTML tag NOTES
//#     code -  DamicBillBoard is the name of this class
//#     width - the width of the applet.  Must be the same size as the images
//#     height - the height of the applet. Must be the same size as the images
//#     delay - the time between images in milliseconds
//#     billboards - the number of different BillBoards(images) that you will 
//#             use
//#     bill# - the image followed by the linking URL for a given BillBoard,
//#             starting with number 0.  this followed by a string that will appear on
//#             status bar when the mouse is over the billboard.  
//#             The image and URL should be separated
//#             by a comma, *NO SPACES*
//#     bill#... - this parameter should appear 0 to one less then the value of
//#             the "billboards" parameter.  Replace # with the BillBoards 
//#             number
//#     transitions - the number of classes that will be used as transitions,
//#             followed by the names of these classes, separated by commas
//#             *NO SPACES*
//#             right now I have supplied 6 transitions.  Feel free to 
//#             add your own.
//#     bgcolor - OPTIONAL - the background color the applet will use.  The value 
//#             is similar to how one specifies the bgcolor tag in HTML.
//##############################################################################
