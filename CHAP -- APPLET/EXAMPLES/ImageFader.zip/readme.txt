*** Documentation about Demicron's "Imagefader" java-applet ***
********* Version 1.0, programmed by Anibal Wainstein ********* 

Licence agreement:

The registration number for this applet is A00012.
Note that Demicron doesn't take any responsibility against damage this 
applet may do to your system or another. The applet is freeware and 
may be used commercially by anyone. It may not be altered in any way.

Description:
              
If you want a nice slideshow then you should use this applet. The applet
collects a number of equal-sized pictures and shows them by fading one
to another in a cycle. You can also specify an URL connected to the 
picture that is applied when the user clicks on the picture. Note that
the applet space MUST be of the same size as the pictures and ALL the 
pictures MUST have equal dimensions.

Configuration:

* "demicron" (must be "www.demicron.se") Required parameter.
* "reg" (must be "A00012") Required parameter.
* "width" (integer number) Applet and picture width.
* "height" (integer number) Applet and picture height.
* "sleeptime" (integer number) The time a picture will be shown before
  it fades to another.
* "step" (floating point number) The detail of the fade in percent. A
  lower number gives best detail. Should be around 0.05.
* "delay" (integer  number) Fade delay. Should be around 20.
* "maxitems" (integer number) Number of images and URLs.
* "bitmapxx" (text) The name of the picture xx.
* "urlxx" (text) The URL of picture xx. If you dont want any, just write
  a " " (space character).

Here is an example of a HTML-configuration:

<APPLET CODE="imagefader.class" WIDTH=80 HEIGHT=107>
<PARAM name="demicron" value="www.demicron.se">
<PARAM name="reg" value="A00012">
<PARAM name="maxitems" value="3">
<PARAM name="width" value="80">
<PARAM name="height" value="107">
<PARAM name="bitmap0" value="anibal.jpg">
<PARAM name="bitmap1" value="jak.jpg">
<PARAM name="bitmap2" value="jan.jpg">
<PARAM name="url0" value="http://www.nada.kth.se/~nv92-awa/">
<PARAM name="url1" value="http://www.nada.kth.se/~nv92-jak/">
<PARAM name="url2" value="http://www.nada.kth.se/~nv92-jfu/">
<PARAM name="step" value="0.05">
<PARAM name="delay" value="20">
<PARAM name="sleeptime" value="2000">
</APPLET>
